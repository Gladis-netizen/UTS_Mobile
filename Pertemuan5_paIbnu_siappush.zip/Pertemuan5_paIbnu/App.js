import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Ionicons from "@expo/vector-icons/Ionicons";

import Home from "./screens/home";
import Profile from "./screens/profile";
import Login from "./screens/login";

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// 1. Komponen Tab Navigation dengan Tema Pink
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: "#EC4899", // Warna pink cerah saat aktif
        tabBarInactiveTintColor: "#F472B6", // Warna pink muda/soft saat tidak aktif
        tabBarStyle: {
          backgroundColor: "#FFF1F2", // Background bar agak pink soft
          borderTopColor: "#FBCFE8",
        },
      }}
    >
      <Tab.Screen
        name="Home"
        component={Home}
        options={{
          tabBarIcon: ({ focused, color, size }) => (
            <Ionicons
              name={focused ? "home" : "home-outline"}
              size={size}
              color={color}
            />
          ),
        }}
      />

      <Tab.Screen
        name="Profile"
        component={Profile}
        options={{
          tabBarIcon: ({ focused, color, size }) => (
            <Ionicons
              name={focused ? "person" : "person-outline"}
              size={size}
              color={color}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

// 2. Alur Utama: Tampilan awal Login, lalu masuk ke MainTabs
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="MainTabs" component={MainTabs} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}