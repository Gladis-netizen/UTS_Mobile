
import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function Profile({ onLogout }) {
  const handleLogout = () => {
    Alert.alert(
      "Konfirmasi Logout",
      "Apakah kamu yakin ingin keluar?",
      [
        {
          text: "Batal",
          style: "cancel",
        },
        {
          text: "Ya, Logout",
          style: "destructive",
          onPress: () => {
            if (onLogout) {
              onLogout();
            }
          },
        },
      ]
    );
  };

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
    >
      {/* HEADER */}
      <Text style={styles.title}>My Profile</Text>

      {/* PROFILE CARD */}
      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <Ionicons
            name="person"
            size={55}
            color="#D94F89"
          />
        </View>

        <Text style={styles.name}>Anggita</Text>

        <Text style={styles.role}>
          Mahasiswa
        </Text>
      </View>

      {/* INFORMASI MAHASISWA */}
      <Text style={styles.sectionTitle}>
        Informasi Mahasiswa
      </Text>

      <View style={styles.infoCard}>
        <View style={styles.infoRow}>
          <Ionicons
            name="person-outline"
            size={22}
            color="#D94F89"
          />

          <View style={styles.infoText}>
            <Text style={styles.label}>
              Nama Lengkap
            </Text>
            <Text style={styles.value}>
              Anggita
            </Text>
          </View>
        </View>

        <View style={styles.line} />

        <View style={styles.infoRow}>
          <Ionicons
            name="card-outline"
            size={22}
            color="#D94F89"
          />

          <View style={styles.infoText}>
            <Text style={styles.label}>NIM</Text>
            <Text style={styles.value}>
              4112755201250035
            </Text>
          </View>
        </View>

        <View style={styles.line} />

        <View style={styles.infoRow}>
          <Ionicons
            name="school-outline"
            size={22}
            color="#D94F89"
          />

          <View style={styles.infoText}>
            <Text style={styles.label}>
              Program Studi
            </Text>
            <Text style={styles.value}>
              Informatika
            </Text>
          </View>
        </View>
      </View>

      {/* LOGOUT */}
      <TouchableOpacity
        style={styles.logoutButton}
        onPress={handleLogout}
        activeOpacity={0.8}
      >
        <Ionicons
          name="log-out-outline"
          size={22}
          color="#FFFFFF"
        />

        <Text style={styles.logoutText}>
          Logout
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF5F9",
    paddingHorizontal: 16,
  },

  title: {
    fontSize: 25,
    fontWeight: "bold",
    color: "#A9366C",
    marginTop: 45,
    marginBottom: 20,
  },

  profileCard: {
    backgroundColor: "#D94F89",
    borderRadius: 15,
    padding: 25,
    alignItems: "center",
    marginBottom: 25,
  },

  avatar: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
    borderWidth: 3,
    borderColor: "#F9C6DC",
  },

  name: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#FFFFFF",
  },

  role: {
    fontSize: 13,
    color: "#FFE3EF",
    marginTop: 5,
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#A9366C",
    marginBottom: 12,
  },

  infoCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 18,
    borderWidth: 1,
    borderColor: "#F5D4E2",
    elevation: 3,
  },

  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
  },

  infoText: {
    marginLeft: 15,
    flex: 1,
  },

  label: {
    fontSize: 12,
    color: "#A18493",
  },

  value: {
    fontSize: 15,
    fontWeight: "bold",
    color: "#63354A",
    marginTop: 3,
  },

  line: {
    height: 1,
    backgroundColor: "#F5E3EB",
    marginVertical: 5,
  },

  logoutButton: {
    backgroundColor: "#D94F89",
    borderRadius: 10,
    padding: 15,
    marginTop: 30,
    marginBottom: 40,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },

  logoutText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "bold",
  },
});
