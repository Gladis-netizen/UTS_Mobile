import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function Home({ navigation }) {
  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* JUDUL */}
        <Text style={styles.title}>HOME PAGE</Text>

        {/* PROFIL */}
       
        {/* PROFIL */}
        <View style={styles.profile}>
          <View style={styles.photo}>
            <Image
              source={require("../assets/fotoaku.jpeg")}
              style={styles.profileImage}
              resizeMode="cover"
            />
          </View>

          <Text style={styles.name}>ANGGITA</Text>
          <Text style={styles.role}>MAHASISWA</Text>
        </View>


        {/* MENU */}
        <View style={styles.menuGrid}>
          <TouchableOpacity
            style={styles.menu}
            onPress={() => navigation.navigate("Tugas")}
          >
            <Ionicons
              name="book-outline"
              size={25}
              color="#C64D83"
            />
            <Text style={styles.menuText}>MENU 1</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menu}
            onPress={() => navigation.navigate("Jadwal")}
          >
            <Ionicons
              name="calendar-outline"
              size={25}
              color="#C64D83"
            />
            <Text style={styles.menuText}>MENU 2</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menu}
            onPress={() => navigation.navigate("Absensi")}
          >
            <Ionicons
              name="clipboard-outline"
              size={25}
              color="#C64D83"
            />
            <Text style={styles.menuText}>MENU 3</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menu}
            onPress={() => navigation.navigate("Pengumuman")}
          >
            <Ionicons
              name="notifications-outline"
              size={25}
              color="#C64D83"
            />
            <Text style={styles.menuText}>MENU 4</Text>
          </TouchableOpacity>
        </View>

        {/* LOGOUT */}
        <TouchableOpacity
          style={styles.logout}
          onPress={() => {
            navigation.reset({
              index: 0,
              routes: [{ name: "Login" }],
            });
          }}
        >
          <Ionicons
            name="log-out-outline"
            size={18}
            color="#FFFFFF"
          />
          <Text style={styles.logoutText}>TOMBOL LOGOUT</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF5F9",
  },

  content: {
    flexGrow: 1,
    alignItems: "center",
    paddingHorizontal: 24,
    paddingTop: 45,
    paddingBottom: 30,
  },

  title: {
    fontSize: 23,
    fontWeight: "bold",
    color: "#C64D83",
    marginBottom: 25,
  },

  profile: {
    width: "100%",
    minHeight: 180,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#F0BBD1",
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    padding: 18,
    marginBottom: 18,
  },

  photo: {
    width: 76,
    height: 76,
    borderRadius: 20,
    backgroundColor: "#FCE1EC",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#E9A5C1",
    marginBottom: 8,
  },

  name: {
    fontSize: 15,
    fontWeight: "bold",
    color: "#A9366C",
  },

  role: {
    fontSize: 10,
    color: "#9D7186",
    marginTop: 4,
  },

  menuGrid: {
    width: "100%",
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  menu: {
    width: "48%",
    height: 90,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#F0BBD1",
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
    gap: 5,
  },

  menuText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#A9366C",
  },

  logout: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#D94F89",
    borderRadius: 8,
    paddingVertical: 11,
    paddingHorizontal: 22,
    marginTop: 12,
    gap: 7,
  },

  logoutText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "bold",
  },
  profileImage: {
  width: "100%",
  height: "100%",
  borderRadius: 20,
  },
});
